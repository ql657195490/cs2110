#ifndef LVL2_BITMAP_H
#define LVL2_BITMAP_H
extern const unsigned short lvl2[3600];
#define LVL2_WIDTH 80
#define LVL2_HEIGHT 45
#endif