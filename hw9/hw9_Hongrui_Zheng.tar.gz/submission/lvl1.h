#ifndef LVL1_BITMAP_H
#define LVL1_BITMAP_H
extern const unsigned short lvl1[12800];
#define LVL1_WIDTH 80
#define LVL1_HEIGHT 160
#endif