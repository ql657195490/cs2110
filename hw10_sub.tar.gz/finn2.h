/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=4 finn2 finn2.gif 
 * Time-stamp: Thursday 11/05/2015, 15:53:29
 * 
 * Image Information
 * -----------------
 * finn2.gif (frame 0) 96@126
 * finn2.gif (frame 1) 96@126
 * finn2.gif (frame 2) 96@126
 * finn2.gif (frame 3) 96@126
 * finn2.gif (frame 4) 96@126
 * finn2.gif (frame 5) 96@126
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef FINN2_H
#define FINN2_H

extern const unsigned short finn2_palette[6];
#define FINN2_PALETTE_SIZE 6

extern const unsigned short finn20[6048];

extern const unsigned short finn21[6048];

extern const unsigned short finn22[6048];

extern const unsigned short finn23[6048];

extern const unsigned short finn24[6048];

extern const unsigned short finn25[6048];

extern const unsigned short* finn2_frames[6];
#define FINN2_FRAMES 6
#define FINN2_SIZE 6048
#define FINN2_WIDTH 96
#define FINN2_HEIGHT 126

#endif

