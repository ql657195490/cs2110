/*
 * Exported with nin10kit v1.1
 * Invocation command was nin10kit -mode=3 kitty kitty.bmp 
 * Time-stamp: Tuesday 11/03/2015, 18:04:47
 * 
 * Image Information
 * -----------------
 * kitty.bmp 150@110
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef KITTY_H
#define KITTY_H

extern const unsigned short kitty[16500];
#define KITTY_SIZE 16500
#define KITTY_WIDTH 150
#define KITTY_HEIGHT 110

#endif

